import { useState } from 'react';

export default function HotelServiceUI() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [selectedService, setSelectedService] = useState(null);
  const [confirmation, setConfirmation] = useState(null);

  const handleLogin = () => {
    if (username.trim() && password.trim()) {
      setIsAuthenticated(true);
    }
  };

  const handleFloorSelection = async (floor) => {
    try {
      const response = await fetch('https://testhotelsite.com/api/request-service', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          service: selectedService,
          floor: floor
        })
      });

      const result = await response.json();
      setConfirmation(`Service requested: ${result.status || 'Success'}`);
    } catch (error) {
      console.error('Error sending service request:', error);
      setConfirmation('Failed to request service.');
    }
  };

  if (!isAuthenticated) {
    return (
      <div style={{ padding: 20, maxWidth: 400, margin: '0 auto' }}>
        <h2>Login</h2>
        <input
          style={{ padding: 8, marginBottom: 10, width: '100%' }}
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          style={{ padding: 8, marginBottom: 10, width: '100%' }}
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button onClick={handleLogin} style={{ padding: 10, width: '100%' }}>Login</button>
      </div>
    );
  }

  if (!selectedService) {
    return (
      <div style={{ padding: 20 }}>
        <h2>Select a Service</h2>
        <button onClick={() => setSelectedService('trash')} style={{ padding: 10, marginRight: 10 }}>Trash</button>
        <button onClick={() => setSelectedService('laundry')} style={{ padding: 10 }}>Laundry</button>
      </div>
    );
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>{selectedService === 'trash' ? 'Trash Collection' : 'Laundry Pickup'}</h2>
      {[1, 2, 3, 4, 5, 6].map(floor => (
        <button key={floor} onClick={() => handleFloorSelection(floor)} style={{ display: 'block', padding: 10, marginTop: 10 }}>
          Floor {floor}
        </button>
      ))}
      <button onClick={() => { setSelectedService(null); setConfirmation(null); }} style={{ marginTop: 20 }}>Back</button>
      {confirmation && <p style={{ color: 'green' }}>{confirmation}</p>}
    </div>
  );
}
